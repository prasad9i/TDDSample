sap.ui.define([
		"test/unit/model/formatter",
		"test/unit/model/models",
		"test/unit/controller/View1.controller"
	], function() {
		"use strict";
	}
);